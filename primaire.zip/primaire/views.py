from django.shortcuts import render

# Create your views here.
from django.contrib import messages
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse

from blog.models import *

def home(request):
    return render(request, 'primaire/primaire_eng.html')

def home_fr(request):
    return render(request, 'primaire/primaire_fr.html')