from django.urls import path
from . import views
from django.urls import reverse

app_name = 'primaire'

urlpatterns=[
    path('en/', views.home, name = 'home_en'),
    path('fr/', views.home, name = 'home_fr')
]